package com.klu.Controller;
import com.klu.application.entity.Jobseeker;
import com.klu.Service.JobseekerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/jobseeker")
public class JobseekerController {

    @Autowired
    private JobseekerService jobseekerService;

    @PostMapping("/register")
    public ResponseEntity<String> registerJobseeker(@RequestBody Jobseeker jobseeker) {
        jobseekerService.saveJobseeker(jobseeker);
        return ResponseEntity.ok("Jobseeker registered successfully!");
    }
	

}
