package com.klu.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.klu.Service.StudentService;
import com.klu.application.entity.Student;

@Controller
@RequestMapping("/student")
public class StudentController {
	  @Autowired
	    private StudentService studentService;

	    @GetMapping("/register")
	    public String showStudentRegistrationForm(Model model) {
	        model.addAttribute("student", new Student());
	        return "student_register";
	    }

	    @PostMapping("/register")
	    public String registerStudent(@ModelAttribute Student student) {
	        studentService.saveStudent(student);
	        return "redirect:/slogin";
	    }

}
