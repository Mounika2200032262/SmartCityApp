package com.klu.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klu.application.entity.Business;

//BusinessService.java
@Service
public class BusinessService {
 @Autowired
 private BusinessService businessRepository;

 public Business saveBusiness(Business business) {
     return businessRepository.saveBusiness(business);
 }
}

