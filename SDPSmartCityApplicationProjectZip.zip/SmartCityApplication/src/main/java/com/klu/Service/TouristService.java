package com.klu.Service;
import com.klu.application.entity.Tourist;
import com.klu.JpaRepository.TouristRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class TouristService {
	@Autowired
    private TouristRepository touristRepository;

    public Tourist saveTourist(Tourist tourist) {
        return touristRepository.save(tourist);
    }

}
