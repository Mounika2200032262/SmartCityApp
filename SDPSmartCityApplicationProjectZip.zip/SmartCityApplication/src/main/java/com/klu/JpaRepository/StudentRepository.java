package com.klu.JpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klu.application.entity.Student;
public interface StudentRepository extends JpaRepository<Student, Long>{

}
