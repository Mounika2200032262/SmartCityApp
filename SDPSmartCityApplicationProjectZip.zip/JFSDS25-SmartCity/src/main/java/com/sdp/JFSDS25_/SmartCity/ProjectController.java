package com.sdp.JFSDS25_.SmartCity;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProjectController {

    @GetMapping("/")
    public String home(@RequestParam(value = "username", required = false) String username, Model model) {
        if (username != null) {
            System.out.println("Username received: " + username);
            model.addAttribute("username", username);
        }
        return "home";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    // Tourist module
    @GetMapping("/tindex")
    public String tindex() {
        return "tindex";
    }

    @GetMapping("/tlogin")
    public String tlogin() {
        return "tlogin";
    }

    @GetMapping("/tregister")
    public String tregister() {
        return "tregister"; // Add this JSP for tourist registration
    }

    @GetMapping("/tviewInfo")
    public String tviewInfo(Model model) {
        return "tviewInfo";
    }

    @GetMapping("/tlogout")
    public String tlogout() {
        return "tlogout";
    }

    // Student module
    @GetMapping("/sindex")
    public String sindex() {
        return "sindex";
    }

    @GetMapping("/slogin")
    public String slogin() {
        return "slogin";
    }

    @GetMapping("/sregister")
    public String sregister() {
        return "sregister"; // Add this JSP for student registration
    }

    @GetMapping("/sviewInfo")
    public String sviewInfo(Model model) {
        return "sviewInfo";
    }

    @GetMapping("/slogout")
    public String slogout() {
        return "slogout";
    }

    // Business module
    @GetMapping("/bindex")
    public String bindex() {
        return "bindex";
    }

    @GetMapping("/blogin")
    public String blogin() {
        return "blogin";
    }

    @GetMapping("/bregister")
    public String bregister() {
        return "bregister"; // Add this JSP for business registration
    }

    @GetMapping("/bviewInfo")
    public String bviewInfo(Model model) {
        return "bviewInfo";
    }

    @GetMapping("/blogout")
    public String blogout() {
        return "blogout";
    }

    // Jobseeker module
    @GetMapping("/jsindex")
    public String jsindex() {
        return "jsindex";
    }

    @GetMapping("/jslogin")
    public String jslogin() {
        return "jslogin";
    }

    @GetMapping("/jsregister")
    public String jsregister() {
        return "jsregister"; // Add this JSP for jobseeker registration
    }

    @GetMapping("/jsviewInfo")
    public String jsviewInfo(Model model) {
        return "jsviewInfo";
    }

    @GetMapping("/jslogout")
    public String jslogout() {
        return "jslogout";
    }

    // Admin module
    @GetMapping("/admin")
    public String adminDashboard(Model model) {
        return "admin"; // JSP path for the admin dashboard
    }

    @GetMapping("/users")
    public String manageUsers(Model model) {
        return "users"; // JSP path for managing users
    }

    @GetMapping("/city-info")
    public String manageCityInfo(Model model) {
        return "city-info"; // JSP path for managing city info
    }

    @GetMapping("/issues")
    public String viewIssues(Model model) {
        return "issues"; // JSP path for viewing issues
    }

    @GetMapping("/analytics")
    public String viewAnalytics(Model model) {
        return "analytics"; // JSP path for analytics dashboard
    }

    @GetMapping("/add-place")
    public String addPlaceForm(Model model) {
        return "add-place"; // JSP path for adding a place
    }

    @GetMapping("/view-places")
    public String viewPlaces(Model model) {
        return "view-places"; // JSP path for viewing places
    }

    @GetMapping("/adlogin")
    public String adlogin() {
        return "adlogin";
    }

    @GetMapping("/adlogout")
    public String adlogout() {
        return "redirect:/"; // Redirect to home after logout
    }
}
